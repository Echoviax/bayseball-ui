export default function AboutPage() {
    return (
        <div className="max-w-3xl mt-24 mx-auto justify-center">
            <span className="text-xl font-semibold text-center flex">This is a work in progress</span>
        </div>
    )
}