export type Team = {
    name: string;
    location: string;
    color: string;
    emoji: string;
    motto: string;
    id: string;
}